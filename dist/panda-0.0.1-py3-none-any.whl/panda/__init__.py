def test1():
    print('test1enfet')

print("en plein milieu mdr")

if __name__ == '__main__':
    print("main")